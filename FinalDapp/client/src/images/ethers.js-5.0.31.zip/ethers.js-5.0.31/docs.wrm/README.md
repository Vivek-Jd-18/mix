Documentation
=============

These docs are built using [Flatworm Docs](https://github.com/ricmoo/flatworm).

The output is placed in [docs](../docs) and generates both HTML and Markdown
files.


Building
--------

```
/home/ricmoo/ethers.js> npm run build-docs
```


License
-------

All documentation for ethers.js and Flatworm is released under the
[Creative Commons Attribution 4.0 International License](https://choosealicense.com/licenses/cc-by-4.0/)
license.
