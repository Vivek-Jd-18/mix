export declare function getOrdered(skipNobuild?: boolean): Array<string>;
export declare function sort(dirnames: Array<string>): void;
