export declare function setupBuild(buildModule: boolean): void;
