export declare function getGitTag(filename: string): Promise<string>;
