#!/bin/bash

npx tsc -w
