declare const major: any;
