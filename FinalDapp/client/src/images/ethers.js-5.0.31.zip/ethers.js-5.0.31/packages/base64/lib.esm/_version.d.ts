export declare const version = "base64/5.0.8";
//# sourceMappingURL=_version.d.ts.map