"use strict";

export { decode, encode } from "./base64";
