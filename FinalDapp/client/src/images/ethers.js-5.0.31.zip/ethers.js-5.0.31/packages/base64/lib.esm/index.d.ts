export { decode, encode } from "./base64";
//# sourceMappingURL=index.d.ts.map