"use strict";
export { decode, encode } from "./base64";
//# sourceMappingURL=index.js.map