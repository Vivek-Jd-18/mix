export declare const version = "abstract-provider/5.0.9";
//# sourceMappingURL=_version.d.ts.map