export const version = "abstract-provider/5.0.9";
