export declare const version = "address/5.0.10";
//# sourceMappingURL=_version.d.ts.map