export const version = "address/5.0.10";
//# sourceMappingURL=_version.js.map