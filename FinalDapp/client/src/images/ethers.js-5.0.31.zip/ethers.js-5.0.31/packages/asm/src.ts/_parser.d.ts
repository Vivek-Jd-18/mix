export function parse(source: string): any;
export const parser: { yy: { [ key: string ]: any } };
