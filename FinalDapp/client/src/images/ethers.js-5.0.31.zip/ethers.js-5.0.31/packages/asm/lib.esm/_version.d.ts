export declare const version = "asm/5.0.10";
//# sourceMappingURL=_version.d.ts.map