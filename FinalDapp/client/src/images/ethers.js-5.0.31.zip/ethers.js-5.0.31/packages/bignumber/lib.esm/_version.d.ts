export declare const version = "bignumber/5.0.14";
//# sourceMappingURL=_version.d.ts.map