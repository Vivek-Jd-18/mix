export const version = "abi/5.0.12";
//# sourceMappingURL=_version.js.map