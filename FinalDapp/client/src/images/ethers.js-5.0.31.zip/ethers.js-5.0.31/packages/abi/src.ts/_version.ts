export const version = "abi/5.0.12";
