export declare const version = "abi/5.0.12";
//# sourceMappingURL=_version.d.ts.map