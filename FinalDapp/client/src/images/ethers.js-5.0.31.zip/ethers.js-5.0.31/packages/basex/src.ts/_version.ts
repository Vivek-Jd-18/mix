export const version = "basex/5.0.8";
