export const version = "basex/5.0.8";
//# sourceMappingURL=_version.js.map