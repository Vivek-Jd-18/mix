export declare const version = "basex/5.0.8";
//# sourceMappingURL=_version.d.ts.map