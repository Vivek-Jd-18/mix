export declare const version = "abstract-signer/5.0.13";
//# sourceMappingURL=_version.d.ts.map